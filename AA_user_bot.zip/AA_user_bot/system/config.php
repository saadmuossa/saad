<?php
$load_addons = 'AA_user_bot';
require_once('../../../system/config_addons.php');
if(!boomAllow(10)){
	die();
}
?>
<?php echo elementTitle($data['addons'], 'loadLob(\'admin/setting_addons.php\');'); ?>
<div class="page_full">
	<div>
		<div class="tab_menu">
			<ul>
				<li class="tab_menu_item tab_selected" data="user_bot" data-z="bot_setting"><i class="fa fa-cogs"></i> New Guest </li>
				<li class="tab_menu_item" onclick="showListUserBot();" data="user_bot" data-z="list_bot"><i class="fa fa-cogs"></i> <?php echo $lang['settings']; ?></li>
			</ul>
		</div>
	</div>
	<div id="user_bot">
	<div id="bot_setting" class="tab_zone">
	<div class="page_element">
		<div class="tpad15" id="hide_user_Boot">
			<div class="pad_box">
		<div class="setting_element">
			<p class="label"><?php echo $lang['username']; ?></p>
			<input id="set_create_name" class="full_input" type="text" maxlength="<?php echo $data['max_username']; ?>" />
		</div>
		<div class="setting_element">
			<p class="label"><?php echo $lang['room_name']; ?></p>
			<select id="room_name">
				<?php echo roomSelect(1); ?>
			</select>
		</div>
		<div class="setting_element">
			<input id="set_create_email" class="hide_zone full_input" type="text" maxlength="80" value="<?php echo ''.time().'user_'.lastRecordedId().'@gmail.com'; ?>"/>
		</div>
		<div class="setting_element">
			<p class="label"><?php echo $lang['gender']; ?></p>
			<select id="set_create_gender">
				<?php echo listGender($data['user_sex']); ?>
			</select>
		</div>
		<div class="setting_element">
			<p class="label"><?php echo $lang['age']; ?></p>
			<select id="set_create_age">
				<?php echo listAge($data['min_age'], 2); ?>
			</select>
		</div>
	<button class="theme_btn reg_button tmargin5" onclick="addNewUserBot();" id="add_new_user"><i class="fa fa-plus"></i> <?php echo $lang['create']; ?></button>
</div>
</div>

</div>
</div>
<div id="list_bot" class="tab_zone hide_zone">
<div style="padding:8px !important" class="pad_box">
	<div class="boom_form">
	<div class="page_element">
     <div class="bold">
        <p class="label " style="text-align: center;">List of fictitious names</p>
		<div id="Show_loding_prim"></div>
		<div class="ulist_container">
	    <div id="list_user_boot" class="tpad10 box_height">
		</div>
        </div>
      </div>
	</div>
	</div>
</div>
</div>
</div>
		</div>
		<div class="config_section">
<style>
.floor_p{	
    font-size: 15px;
    font-weight: bold;
}
#deletePRi{
text-align: center;
font-weight: bold;
color: black;}
</style>
<style>
.lite_olay{
border-radius:6px !important;
}
.score_lm { display:table-cell; vertical-align:middle; width:70px; text-align:right; font-weight:bold; padding:0 5px; }
.ranking_lm { display:table-cell; vertical-align:middle; width:30px; text-align:center; font-weight:bold; }
.quiz_leaderbox { width:100%; max-height:400px; overflow:hidden; overflow-y:auto; }
</style>

<script data-cfasync="false" type="text/javascript">
showListUserBot = function(){
					$.post('addons/AA_user_bot/system/action.php', {
						load_user_boot: 1,
						token: utk,
						}, function(response) {
							$('#rank_find').val('');
							$('#list_user_boot').html(response);
					});
}
var deletePRi = '<div id="deletePRi"><i class="fa fa-spin fa-repeat"></i><p class="floor_p">L O D I N G . . . </p></div>';
deletUserBot = function(id){
					$.post('addons/AA_user_bot/system/action.php', {
						id:id,
						token: utk,
						}, function(response) {
							if(response == 1){
								callSaved(system.saved, 1);
								$('.delet_user'+id).remove();
							}
							else{
							callSaved(system.saved, 3);
							}
					});	
}
waitCreate = 0;
addNewUserBot = function(){
	if(waitCreate == 0){
		waitCreate = 1;
		$(deletePRi).insertAfter('#hide_user_Boot').show;
		$('#hide_user_Boot').hide();
		$.post('addons/AA_user_bot/system/action.php', {
			create_user: 1,
			create_name: $('#set_create_name').val(),
			room_name: $('#room_name').val(),
			create_email: $('#set_create_email').val(),
			create_gender: $('#set_create_gender').val(),
			create_age: $('#set_create_age').val(),
			token: utk
			}, function(response) {
				if(response == 5){
					callSaved(system.invalidEmail, 3);
					$('#deletePRi').hide();
					$('#hide_user_Boot').show();
				}
				else if(response == 6){
					callSaved(system.emailExist, 3);
					$('#deletePRi').hide();
					$('#hide_user_Boot').show();
				}
				else if(response == 4){
					callSaved(system.usernameExist, 3);
					$('#deletePRi').hide();
					$('#hide_user_Boot').show();
				}
				else if(response == 3){
					callSaved(system.invalidUsername, 3);
					$('#deletePRi').hide();
					$('#hide_user_Boot').show();
				}
				else if(response == 2){
					callSaved(system.emptyField, 3);
					$('#deletePRi').hide();
					$('#hide_user_Boot').show();
				}
				else if (response == 1){
					$('#hide_user_Boot').show();
					$('#deletePRi').hide();
					callSaved(system.saved, 1);
					hideModal();
				}
				waitCreate = 0;
		});
	}
}
</script>

		</div>