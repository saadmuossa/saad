<?php
if (!defined('BOOM')){
  die();
}

$ad = array(
	'name' => 'AA_user_bot',
	'access' => 0,
);
$mysqli->query("ALTER TABLE `boom_users`ADD `user_fake` INT(11) NULL DEFAULT '0';");
?>