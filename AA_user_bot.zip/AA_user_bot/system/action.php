<?php

$load_addons = "AA_user_bot";
require_once "../../../system/config_addons.php";
foreach ($_POST as $key => $value) {
    ${$key} = escape($value);
}
if (boomAllow(9)) {
    // @ioncube.dynamickey encoding key: boommerge('yildiz1', 'ameer1')
    // Encryption type: 1
    function loadPrimSs($Prim, $num, $allow)
    {
        global $lang;
        $add_me = "";
        $room = roomInfo($Prim["user_roomid"]);
        return "<div class=\"ulist_item " . $add_me . " delet_user" . $Prim["user_id"] . "\">\r\n\t\t\t\t<div class=\"ranking_lm\">\r\n\t\t\t\t\t" . $num . "\r\n\t\t\t\t</div>\r\n\t\t\t\t<div class=\"get_info ulist_avatar\" data=\"" . $Prim["user_id"] . "\">\r\n\t\t\t\t\t<img src=\"" . myAvatar($Prim["user_tumb"]) . "\"/>\r\n\t\t\t\t</div>\r\n\t\t\t\t<div class=\"ulist_name\">\r\n\t\t\t\t\t<p class=\"username " . $Prim["tcolor"] . "\">" . $Prim["user_name"] . "</p>\r\n\t\t\t\t</div>\r\n\t\t\t\t<b>" . $lang["room_name"] . " (" . $room["room_name"] . ")</b>\r\n\t\t\t\t<div class=\"score_lm\" onclick=\"deletUserBot(" . $Prim["user_id"] . ");\">\r\n\t\t\t\t<div class=\"cover_item_wrap lite_olay\">\r\n\t\t\t\t\t\t<div class=\"cover_item delete_cover\">\r\n\t\t\t\t\t\t\t<i id=\"cover_button\" class=\"fa fa-times\"></i>\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t<div class=\"cover_item add_cover hide_phone\">\r\n\t\t\t\t\t\t\t\t" . $lang["delete"] . " <i id=\"cover_icon\"></i>\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</div>\r\n\t\t\t</div>";
    }
    // @ioncube.dynamickey encoding key: boommerge('yildiz12', 'ameer12')
    // Encryption type: 6
    function selUserArray()
    {
        global $data;
        global $lang;
        global $mysqli;
        $bot_list = "";
        $get_Prime = $mysqli->query("SELECT * FROM boom_users WHERE user_fake = 1 AND user_bot = 0 ORDER BY user_id DESC LIMIT 150");
        if (0 < $get_Prime->num_rows) {
            for ($num = 1; $Prim = $get_Prime->fetch_assoc(); $num++) {
                $bot_list .= loadPrimSs($Prim, $num, $mysq, $room);
            }
        } else {
            $bot_list .= emptyZone($lang["no_data"]);
        }
        echo $bot_list;
        exit;
    }
    if (isset($_POST["load_user_boot"])) {
        selUserArray();
    }
    // @ioncube.dynamickey encoding key: boommerge('yildiz13', 'ameer13')
    // Encryption type: 6
    function boomInsertUserBot($pro)
    {
        global $mysqli;
        global $data;
        global $cody;
        $user = [];
        if (!(isset($pro["name"]) && isset($pro["password"]) && isset($pro["email"]) && isset($pro["room"]))) {
            return $user;
        }
        $def = ["gender" => 3, "age" => 0, "ip" => "0.0.0.0", "language" => $data["language"], "avatar" => "default_avatar.png", "color" => "user", "rank" => 1, "verified" => 0, "verify" => 0, "cookie" => 1, "email" => ""];
        $u = array_merge($def, $pro);
        $time_new = time() + 323432442;
        $mysqli->query("INSERT INTO `boom_users` \r\n\t( user_name, user_password, user_ip, user_email, user_rank, user_roomid, user_theme,\r\n\tuser_join, last_action, user_language, user_timezone, verified, user_verify, user_color,\r\n\tuser_sex, user_age, user_news, user_tumb , user_fake)\r\n\tVALUES \r\n\t('" . $u["name"] . "', '" . $u["password"] . "', '" . $u["ip"] . "', '" . $u["email"] . "', '" . $u["rank"] . "', '" . $u["room"] . "', 'system',\r\n\t'" . time() . "', '" . $time_new . "', '" . $u["language"] . "', '" . $data["timezone"] . "', '" . $u["verified"] . "', '" . $u["verify"] . "', '" . $u["color"] . "',\r\n\t'" . $u["gender"] . "', '" . $u["age"] . "', '" . time() . "', '" . $u["avatar"] . "', '1')");
        $user = userDetails($mysqli->insert_id);
        if ($u["cookie"] == 1 && !empty($user)) {
            setBoomCookie($user["user_id"], $user["user_password"]);
        }
        if ($u["verify"] == 1 && !empty($user)) {
            $send_mail = sendActivation($user);
        }
        return $user;
    }
    // @ioncube.dynamickey encoding key: boommerge('yildiz14', 'ameer14')
    // Encryption type: 1
    function userBotNewF($create_user, $create_name, $room_name, $create_email, $create_gender, $create_age)
    {
        global $data;
        global $lang;
        global $mysqli;
        if (empty($create_name) || empty($room_name) || empty($create_email) || empty($create_gender) || empty($create_age)) {
            echo 2;
            exit;
        }
        if (!boomUsername($create_name)) {
            echo 4;
            exit;
        }
        if (!validName($create_name)) {
            echo 3;
            exit;
        }
        $create_password = "gfdgfdgfdgre4t435";
        $u = ["name" => $create_name, "room" => $room_name, "password" => encrypt($create_password), "gender" => $create_gender, "age" => $create_age, "email" => $create_email, "verify" => 1, "cookie" => 0];
        $user = boomInsertUserBot($u);
        if (!empty($user)) {
            echo 1;
        }
    }
    if (isset($create_user) && isset($create_name) && isset($room_name) && isset($create_email) && isset($create_gender) && isset($create_age) && boomAllow(8)) {
        userBotNewF($create_user, $create_name, $room_name, $create_email, $create_gender, $create_age);
    }
    if (isset($_POST["id"])) {
        $id = escape($_POST["id"]);
        $mysqli->query("DELETE FROM boom_users WHERE user_id = '" . $id . "'");
        echo 1;
        exit;
    }
}

?>